from setuptools import find_packages, setup

setup(
    name="libdir",
    version="1.0.1",
    packages=find_packages(), 
    py_modules= ["libdir"],  
)
